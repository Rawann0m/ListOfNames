//
//  ListOfNamesApp.swift
//  ListOfNames
//
//  Created by Rawan Alradaddi on 04/03/2025.
//

import SwiftUI

@main
struct ListOfNamesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
