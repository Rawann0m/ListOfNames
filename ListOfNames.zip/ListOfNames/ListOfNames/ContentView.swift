//
//  ContentView.swift
//  ListOfNames
//
//  Created by Rawan Alradaddi on 04/03/2025.
//

import SwiftUI

struct ContentView: View {
    @State private var names = ["Rawan", "Sarah", "John", "Amina"]
    @State private var searchLetter = ""
    @State private var isSorted = false

    var body: some View {
        NavigationStack {
            VStack {
                List(searchResults, id: \.self) { name in
                    Text(name)
                }
                .searchable(text: $searchLetter)

                Button(isSorted ? "Shuffle" : "Sort Alphabetically") {
                    isSorted.toggle()
                    names = isSorted ? names.sorted() : names.shuffled()
                }
                .padding()
            }
            .navigationTitle("Name List")
        }
    }

    var searchResults: [String] {
        let filteredNames = searchLetter.isEmpty ? names : names.filter { $0.contains(searchLetter) }
        return isSorted ? filteredNames.sorted() : filteredNames
    }
}

#Preview {
    ContentView()
}

