//
//  ContentView.swift
//  ListOfNames
//
//  Created by Rawan Alradaddi on 04/03/2025.
//

import SwiftUI

struct ContentView: View {
    @State var names = ["Rawan", "Sarah", "John","Amina"]
    @State  var searchLetter = ""
       @State  var isSorted = false
    
    var body: some View {
        NavigationStack {
            List (searchResults, id: \.self){
                name in Text(name)
            }
            .searchable(text: $searchLetter)
            
            Button(isSorted ? "Sort" : "Shuffle"){
                isSorted.toggle()
                names = isSorted ? names.sorted(): names.shuffled()
            }
        }
        .padding()
    }
    var searchResults: [String] {
        if searchLetter.isEmpty{
            return names
        }
        else{
            return names.filter { $0.contains(searchLetter) }
        }
    }
}

#Preview {
    ContentView()
}
